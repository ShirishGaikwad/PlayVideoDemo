//
//  ViewController.h
//  PlayVideoDemo
//
//  Created by Mackintosh on 16/03/14.
//  Copyright (c) 2014 Mackintosh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>
@interface ViewController : UIViewController
{
    
}
- (IBAction)playVideo:(id)sender;

@end
