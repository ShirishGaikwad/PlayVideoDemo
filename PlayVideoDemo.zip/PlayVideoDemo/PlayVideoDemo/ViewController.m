//
//  ViewController.m
//  PlayVideoDemo
//
//  Created by Mackintosh on 16/03/14.
//  Copyright (c) 2014 Mackintosh. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

-(IBAction)playvideo:(id)sender
{
    NSURL *url = [NSURL fileURLWithPath:[[NSBundle mainBundle]pathForResource:@"TAJ" ofType:@"mp4"]];
    MPMoviePlayerViewController * playerContoller = [[MPMoviePlayerViewController alloc]initWithContentURL:url];
    [self presentMoviePlayerViewControllerAnimated:playerContoller];
    
    playerContoller.moviePlayer.movieSourceType = MPMovieSourceTypeFile;
    [playerContoller.moviePlayer play];
    
    [playerContoller release];
    playerContoller=nil;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return YES;//(interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (IBAction)playVideo:(id)sender {
}
@end
