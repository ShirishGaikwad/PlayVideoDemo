## PlayVideoDemo###

===========================================================================
DESCRIPTION:


Demonstrates how to use the Media Player Framework to play a movie in a custom view. The sample will play either a local movie file . The sample also contains code to configure the movie playback controls, scaling mode,  application audio session and repeat mode when transitioning to and from movie playback.


The Media Player framework provides basic facilities for playing movie files. Within the Media Player framework, a ViewController object defines a movie player. You can use this class to play back movies stored in your application�s bundle directory or support directories.  With iPhone OS version 4.0 or later.


Using the Application

After the application launches  to go to the application screen to play the local movie file that is stored in the application bundle. Press the Play Movie button . Also to go to the pause button for pause your movie.As well as fullscreen of movie screen .


===========================================================================
BUILD REQUIREMENTS:

Xcode 4.6, iOS SDK 6.1 or better


===========================================================================
RUNTIME REQUIREMENTS:

iPhone, iPad or iPod Touch running iOS 6.1 or better

===========================================================================
PACKAGING LIST:

AppDelegate.h
AppDelegate.m
A simple UIApplication delegate class that adds the ViewController view to the window as a subview. Instantiates a ViewController object and begins movie playback. 

ViewController.h
ViewController.m
A UIViewController controller subclass that implements a movie playback view. Uses a ViewController object to control playback of a movie.

MainWindow.xib
Interface Builder 'nib' file that defines the iPhone interface for the application: the main window, the view and other user interface items. Also contains the movie file used for playback.

main.m
Entry point for the application. Creates the application object and causes the event loop to start.

TAJ.mp4
The movie file to be played.
===========================================================================
